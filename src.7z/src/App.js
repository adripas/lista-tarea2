import logo from './logo.svg';
import './App.css';
import './css/style.css';
import { useState } from 'react';



function App() {
  /*const [state,setState] = useState ("");*/

  return ( <>
  <main>

    <p><h1>Lista de Tareas</h1></p>

    <div className='write_tarea'>    
    <p> <input className='input' type='text' placeholder='Digite una Tarea'></input> </p>
    <p><button className='button' type='button' onChange={e =>e.target.addEventListener} > Add</button></p>
    </div>
      <div className='contenedor_tarea'>
      <div className='tarea'></div>
      <p><button className='button' type='button'>Eliminar</button></p>

      </div>

  </main>
  
  </>  
    
  );
}


export default App;
